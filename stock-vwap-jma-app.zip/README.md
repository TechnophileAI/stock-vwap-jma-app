# Real-Time VWAP + JMA Stock Chart App

This is a Streamlit-based application to visualize real-time VWAP and JMA indicators for selected US stocks.

## How to Run

1. Create virtual environment:
    ```
    python -m venv venv
    source venv/bin/activate  # or venv\Scripts\activate on Windows
    ```

2. Install dependencies:
    ```
    pip install -r requirements.txt
    ```

3. Start the app:
    ```
    streamlit run app.py
    ```

## Features

- Select from predefined tickers
- View live VWAP and smoothed JMA indicator
- Use interactive multi-stock selector